# Local homepage design study

Three alternatives to compare with the supplied `landing-mockup_1.html`. This folder is independent of the production build and GitHub Pages deployment. None of these drafts replaces the published site or its editable Markdown.

Open **comparison.html** in a browser; this single portable file includes all three layouts, a Writings draft, the content checklist, fonts, portrait, and interactive landscape. Switching views needs no additional server requests. The CV and detailed-page links lead to the existing public site. The Codex in-app browser supports HTTP previews, rather than direct file URLs; use the optional local preview below when reopening it there.

The separate `index.html`, `ribbon.html`, and `column.html` versions are also available. For these individual files, keep this folder's `assets` directory beside them; their CV link uses the local copy of the existing PDF.

- **A. Alongside:** shorter name and an immediate overview beside a prominent burgundy contour. Blue-green links provide a second restrained color. No portrait.
- **B. Landscape ribbon:** the identity and introduction share a row, followed by a broad map and a narrower reading column. Burgundy is the only interface accent.
- **C. Personal column:** a smaller name, a text-first column, the contour in the margin, and the existing portrait beside contact details.
- **Writings:** proposed introduction and section names; empty sections are explicitly a local layout demonstration, not fake posts.
- **Content to fill:** practical prompts for current projects, teaching, the upcoming talk, Writings, software, the CV, and cleanup.

The pale green comparison bar belongs only to this study. Main navigation links scroll to the relevant homepage section; detailed research, teaching, and software links open the corresponding existing public pages. The CV download is the existing May 2026 PDF, not an updated version.

## Editing and preview

Edit `style.css` for appearance, `build.mjs` for draft layouts and copy, and `CONTENT-PLAN.md` for the checklist. From the website repository, run `node design-study/build.mjs` to regenerate the five HTML pages and portable comparison. The build uses the existing `marked` dependency and requires the website dependencies to be installed.

For a browser preview served over HTTP, run `./design-study/preview.ps1` in PowerShell, then visit <http://127.0.0.1:4187/comparison.html>. Stop it with Ctrl+C. The launcher uses the bundled Node runtime when available. The loaded comparison continues switching views after stopping the server; reloading the browser tab requires restarting it. The production preview continues to use port 4186.

## Source and boundaries

The SVG contours and noisy-ascent interaction were extracted from the user's supplied HTML after inspection. The map is a toy landscape, not a research result. The framing was adapted to these layouts, with keyboard input and reduced-motion handling retained. Crimson Text is locally hosted with its license in `assets/FONT-LICENSE.txt`. The portrait and CV are copies of the existing approved site assets.

Draft homepage copy condenses the current public content. It does not assert a formal advisor appointment, group membership, new publication, or completed talk. The eventual selected design should keep the production Markdown editing workflow rather than adopting this mock-up's template text.

See [CONTENT-PLAN.md](CONTENT-PLAN.md) for content prompts and the repository's [CODE_HISTORY.md](../CODE_HISTORY.md) for rationale.
